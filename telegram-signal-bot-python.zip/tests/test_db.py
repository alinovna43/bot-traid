def test_db_import():
    import db
    assert hasattr(db, 'DB')
