def test_payments_import():
    import payments
    assert hasattr(payments, 'create_payment_session')
