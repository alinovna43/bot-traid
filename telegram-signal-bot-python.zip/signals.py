# signals.py code here (from canvas)
